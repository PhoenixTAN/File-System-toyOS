# Discos Approach 2

**Jiaqian Sun U48621793**  
**Ziqi Tan U88387934**

## To run:

```
Enter kernelspace folder, hit "make"
Enter userspace folder, hit "make"
When excute the program, hit "enter" to continue  
```

- int rd_creat(char *pathname, mode_t mode) -- create a regular file with absolute pathname and mode from the root of the directory tree, where each directory filename is delimited by a "/" character.  The mode can be read-write (default), read-only, or write-only . You can assume that any process opening an existing file is restricted by the access rights at creation time. On success, you should return 0, else if the file corresponding to pathname already exists you should return -1, indicating an error. Note that you need to update the parent directory file, to include the new entry. 
- int rd_mkdir(char *pathname) -- this behaves like rd_creat() but pathname refers to a directory file. If the file already exists, return -1 else return 0. Note that you need to update the parent directory file, to include the new entry.
- int rd_open(char *pathname, int flags) -- open an existing file corresponding to pathname (which can be a regular or directory file) or report an error if file does not exist. When opening a file, you should return a file descriptor value that will index into the process'  ramdisk file descriptor table. As stated earlier, this table entry will contain a pointer to a file object. You can assume the file object has status=flags (unless there is an error), and the file position is set to 0. An error can occur when opening a file if the file does not exist or if the flags value overrides the access rights when the file was created. For example, a process should not be allowed to open a file for writing if its access rights are read-only. Finally, you can assume that flags can be any one of READONLY, WRITEONLY, or READWRITE. Return a value of -1 to indicate an access error, or if the file does not exist.
- int rd_close(int fd) -- close the corresponding file descriptor and release the file object matching the value returned from a previous rd_open(). Return 0 on success and -1 on error. An error occurs if fd refers to a non-existent file.
- int rd_read(int fd, char *address, int num_bytes)-- read up to num_bytes from a regular file identified by file descriptor, fd, into a process' location at address. You should return the number of bytes actually read, else -1 if there is an error. An error occurs if the value of fd refers either to a non-existent file or a directory file. If developing DISCOS, you may only have threads within a single shared address space, in which case you should identify a buffer region into which your data is read. 
- int rd_write(int fd, char *address, int num_bytes) -- write up to num_bytes from the specified address in the calling process to a regular file identified by file descriptor, fd. You should return the actual number of bytes written, or -1 if there is an error. An error occurs if the value of fd refers either to a non-existent file or a directory file. If developing DISCOS, you may only have threads within a single shared address space, in which case you should identify a buffer region from which your data is written.
- int rd_lseek(int fd, int offset) -- set the file object's file position identified by file descriptor, fd, to offset, returning the new position, or the end of the file position if the offset is beyond the file's current size. This call should return -1 to indicate an error, if applied to directory files, else 0 to indicate success. 
- int rd_unlink(char *pathname) -- remove the filename with absolute pathname from the filesystem, freeing its memory in the ramdisk. This function returns 0 if successful or -1 if there is an error.  An error can occur if: (1) the pathname does not exist, (2) you attempt to unlink a non-empty directory file, (3) you attempt to unlink an open file, or (4) you attempt to unlink the root directory file. 
- int rd_chmod(char *pathname, mode_t mode) -- change the mode (i.e., access rights) of a file identified by the absolute pathname. Return 0 if successful or a negative value for an error.